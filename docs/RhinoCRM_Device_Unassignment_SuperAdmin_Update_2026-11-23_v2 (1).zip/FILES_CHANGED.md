# RHINO CRM — archivos incluidos

Esta entrega es un paquete de actualización para un CRM RHINO 2.7.0 o posterior. No es una instalación completa de Laravel.

## Archivos nuevos

- `app/Modules/Administration/Controllers/AdminDeviceController.php`
- `app/Modules/Administration/Services/DeviceUnassignmentService.php`
- `database/migrations/2026_11_23_000100_add_device_unassignment_support.php`
- `public/assets/rhino-device-unassignment.js`
- `tests/Standalone/DeviceUnassignmentContractTest.php`
- `PATCHES/routes-api_v1.patch`
- `PATCHES/crm-blade.patch`
- `install.sh`
- `README-ACTUALIZACION-DESVINCULACION-BASCULAS-SUPER-ADMIN.md`
- `FILES_CHANGED.md`
- `UPDATE-MANIFEST-DEVICE-UNASSIGNMENT-2026-11-23.txt`
- `VALIDATION_REPORT.txt`
- `SHA256SUMS.txt`

## Archivos reemplazados

- `app/Modules/IoT/Services/DeviceManagementService.php`
- `app/Modules/IoT/Http/Middleware/VerifyEsp32Signature.php`
- `app/Modules/IoT/Domain/Entities/Device.php`

## Archivos modificados mediante parches

- `routes/api_v1.php`
- `resources/views/crm.blade.php`

Los parches se aplican con `install.sh` desde una carpeta de paquete externa, indicando como argumento la raíz del CRM. El instalador pone el sitio en mantenimiento antes de copiar archivos. La prueba de contrato se ejecuta desde el paquete y no se copia a producción. El paquete conserva las rutas originales y no incluye `.env`, `vendor/`, cachés, logs ni respaldos.
