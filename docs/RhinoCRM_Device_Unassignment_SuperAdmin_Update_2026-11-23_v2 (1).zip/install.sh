#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_INPUT="${1:-$PWD}"
if [[ ! -d "$TARGET_INPUT" ]]; then
  echo "ERROR: no existe la carpeta destino: $TARGET_INPUT" >&2
  exit 1
fi
TARGET_ROOT="$(cd "$TARGET_INPUT" && pwd)"

if [[ "$PACKAGE_DIR" == "$TARGET_ROOT" ]]; then
  echo "ERROR: por seguridad, extrae el paquete fuera de la carpeta del CRM." >&2
  echo "Ejemplo: ~/rhino-device-update y destino ~/rhinocrm" >&2
  exit 1
fi

if [[ ! -f "$TARGET_ROOT/artisan" || ! -f "$TARGET_ROOT/routes/api_v1.php" || ! -f "$TARGET_ROOT/.env" || ! -f "$TARGET_ROOT/vendor/autoload.php" ]]; then
  echo "ERROR: la carpeta destino no parece una instalación Laravel activa de RHINO CRM." >&2
  exit 1
fi

for required in \
  "app/Modules/Administration/Controllers/AdminDeviceController.php" \
  "app/Modules/Administration/Services/DeviceUnassignmentService.php" \
  "app/Modules/IoT/Services/DeviceManagementService.php" \
  "app/Modules/IoT/Http/Middleware/VerifyEsp32Signature.php" \
  "app/Modules/IoT/Domain/Entities/Device.php" \
  "database/migrations/2026_11_23_000100_add_device_unassignment_support.php" \
  "public/assets/rhino-device-unassignment.js" \
  "tests/Standalone/DeviceUnassignmentContractTest.php"; do
  [[ -f "$PACKAGE_DIR/$required" ]] || { echo "ERROR: falta en el paquete: $required" >&2; exit 1; }
done

if command -v sha256sum >/dev/null 2>&1 && [[ -f "$PACKAGE_DIR/SHA256SUMS.txt" ]]; then
  (cd "$PACKAGE_DIR" && sha256sum -c SHA256SUMS.txt)
else
  echo "AVISO: no se pudo comprobar SHA-256 del paquete (sha256sum no disponible)."
fi

command -v patch >/dev/null 2>&1 || { echo "ERROR: se requiere el comando patch." >&2; exit 1; }

cd "$TARGET_ROOT"
php artisan --version

# Verificar que el CRM tiene aplicada la base 2.7.0 antes de tocar archivos.
MIGRATION_STATUS="$(php artisan migrate:status --no-ansi | grep '2026_08_26_000200_rhino_270_devices_assignments_updates' || true)"
if [[ "$MIGRATION_STATUS" != *"Ran"* ]]; then
  echo "ERROR: no aparece aplicada la migración RHINO 2.7.0. No se modificó el CRM." >&2
  exit 1
fi

HAS_ROUTE=0
HAS_IMPORT=0
HAS_BLADE_SCRIPT=0
grep -Fq "Route::post('/devices/{id}/unassign'" routes/api_v1.php && HAS_ROUTE=1 || true
grep -Fq 'use App\Modules\Administration\Controllers\AdminDeviceController;' routes/api_v1.php && HAS_IMPORT=1 || true
grep -Fq 'rhino-device-unassignment.js' resources/views/crm.blade.php && HAS_BLADE_SCRIPT=1 || true

if [[ "$HAS_ROUTE" -eq 1 && "$HAS_IMPORT" -eq 0 ]]; then
  echo "ERROR: la ruta ya existe pero falta el import del controlador. Revisa routes/api_v1.php." >&2
  exit 1
fi
if [[ "$HAS_ROUTE" -eq 0 ]]; then
  patch --dry-run -d "$TARGET_ROOT" -p1 --batch < "$PACKAGE_DIR/PATCHES/routes-api_v1.patch" >/dev/null
fi
if [[ "$HAS_BLADE_SCRIPT" -eq 0 ]]; then
  patch --dry-run -d "$TARGET_ROOT" -p1 --batch < "$PACKAGE_DIR/PATCHES/crm-blade.patch" >/dev/null
fi

# Si el sitio ya estaba en mantenimiento, se respeta ese estado.
PREEXISTING_MAINTENANCE=0
if [[ -f "$TARGET_ROOT/storage/framework/maintenance.php" || -f "$TARGET_ROOT/storage/framework/down" ]]; then
  PREEXISTING_MAINTENANCE=1
fi
MAINTENANCE_STARTED=0
DEPLOY_OK=0

finish_install() {
  local status=$?
  if [[ "$MAINTENANCE_STARTED" -eq 1 ]]; then
    if [[ "$DEPLOY_OK" -eq 1 ]]; then
      if php artisan up; then
        MAINTENANCE_STARTED=0
      else
        echo "ERROR: la actualización terminó, pero no se pudo quitar mantenimiento." >&2
        echo "Cuando revises el error, ejecuta: cd '$TARGET_ROOT' && php artisan up" >&2
        status=1
      fi
    else
      echo "ATENCIÓN: la instalación falló y RHINO permanece en mantenimiento para proteger datos y evitar ejecutar código parcialmente actualizado." >&2
      echo "No ejecutes php artisan up hasta revisar/restaurar el código. Carpeta: $TARGET_ROOT" >&2
      status=1
    fi
  elif [[ "$PREEXISTING_MAINTENANCE" -eq 1 ]]; then
    echo "Aviso: RHINO ya estaba en mantenimiento antes de esta actualización; se conserva ese estado."
  fi
  exit "$status"
}
trap finish_install EXIT

if [[ "$PREEXISTING_MAINTENANCE" -eq 0 ]]; then
  MAINTENANCE_STARTED=1
  php artisan down --retry=60
else
  echo "RHINO ya estaba en mantenimiento; se conservará así al finalizar."
fi

copy_into_crm() {
  local relative="$1"
  mkdir -p "$TARGET_ROOT/$(dirname "$relative")"
  cp -f "$PACKAGE_DIR/$relative" "$TARGET_ROOT/$relative"
}

copy_into_crm "app/Modules/Administration/Controllers/AdminDeviceController.php"
copy_into_crm "app/Modules/Administration/Services/DeviceUnassignmentService.php"
copy_into_crm "app/Modules/IoT/Services/DeviceManagementService.php"
copy_into_crm "app/Modules/IoT/Http/Middleware/VerifyEsp32Signature.php"
copy_into_crm "app/Modules/IoT/Domain/Entities/Device.php"
copy_into_crm "database/migrations/2026_11_23_000100_add_device_unassignment_support.php"
copy_into_crm "public/assets/rhino-device-unassignment.js"

if [[ "$HAS_ROUTE" -eq 0 ]]; then
  patch -d "$TARGET_ROOT" -p1 --batch < "$PACKAGE_DIR/PATCHES/routes-api_v1.patch"
fi
if [[ "$HAS_BLADE_SCRIPT" -eq 0 ]]; then
  patch -d "$TARGET_ROOT" -p1 --batch < "$PACKAGE_DIR/PATCHES/crm-blade.patch"
fi

php artisan migrate --force
php artisan optimize:clear
chmod -R ug+rwX storage bootstrap/cache

ROUTES="$(php artisan route:list --path=api/v1/admin/devices --no-ansi)"
printf '%s\n' "$ROUTES"
grep -q 'unassign' <<< "$ROUTES" || { echo "ERROR: Laravel no registró la ruta de desvinculación." >&2; exit 1; }

php -l app/Modules/Administration/Controllers/AdminDeviceController.php
php -l app/Modules/Administration/Services/DeviceUnassignmentService.php
php -l app/Modules/IoT/Services/DeviceManagementService.php
php -l app/Modules/IoT/Http/Middleware/VerifyEsp32Signature.php
php -l app/Modules/IoT/Domain/Entities/Device.php
php -l database/migrations/2026_11_23_000100_add_device_unassignment_support.php

if command -v node >/dev/null 2>&1; then
  node --check public/assets/rhino-device-unassignment.js
else
  echo "AVISO: Node.js no está instalado; se omitió node --check."
fi

php "$PACKAGE_DIR/tests/Standalone/DeviceUnassignmentContractTest.php"
php artisan migrate:status --no-ansi | grep '2026_11_23_000100_add_device_unassignment_support'

DEPLOY_OK=1
echo "ACTUALIZACIÓN INSTALADA Y VALIDADA."
