# RHINO CRM — Desvinculación de básculas por SUPER_ADMIN

Fecha del paquete: 23 de noviembre de 2026  
Repositorio base: `Regnedy/rhinocrm` (`main`, commit `f4f10991caefce5b18ed99c4af36d2b952caa624`)

## Objetivo

Agregar una acción exclusiva de `SUPER_ADMIN` para desvincular una báscula de un socio sin borrar el dispositivo ni sus mediciones históricas. La báscula queda disponible para que otro socio la registre posteriormente.

La acción se encuentra en:

```text
SUPER ADMIN → Dispositivos → seleccionar socio → Básculas vinculadas → Desvincular
```

## Comportamiento

Al desvincular una báscula, RHINO:

1. Solicita un motivo obligatorio y una confirmación explícita.
2. Cambia el dispositivo a `UNASSIGNED`.
3. Deja `devices.partner_id` y `devices.location_id` en `NULL`.
4. Rota el secreto del dispositivo para invalidar las credenciales anteriores.
5. Desactiva las asociaciones tradicionales de `campaign_devices` sólo para eventos en borrador, programados o activos. Las asociaciones de eventos cerrados/cancelados se conservan para sus vistas históricas.
6. Libera las disponibilidades activas de `campaign_device_availability`.
7. Marca como `REMOVED` las filas personales asociadas, sin eliminarlas y conservando `linked_device_id` para mantener la referencia histórica de eventos.
8. Registra la operación en `security_audit_logs` y `business_movements`, con el socio anterior, motivo, administrador, fecha, MAC y conteos relacionados.
9. Conserva el identificador del dispositivo, `total_measurements`, `last_measurement_at`, las filas de `measurements`, `measurement_intakes`, reportes y movimientos anteriores.

No elimina la báscula, no borra mediciones, no cambia el `partner_id` histórico de las mediciones y no mueve expedientes de clientes.

## Reasignación posterior

La misma MAC podrá registrarse desde otro socio mediante el endpoint de registro existente:

```http
POST /api/v1/devices
```

El registro sólo recupera un dispositivo existente si su estado es exactamente `UNASSIGNED` y no tiene socio asignado. En ese caso:

- reutiliza el mismo `device_id`;
- asigna el nuevo `partner_id` y `location_id`;
- genera y devuelve un secreto nuevo;
- conserva los contadores y mediciones anteriores;
- registra el movimiento `805`.

Las MAC asignadas, suspendidas, revocadas o eliminadas no se pueden recuperar por esta vía. La operación de desvinculación requiere `SUPER_ADMIN`; el registro posterior respeta `devices.create` y el límite del plan del nuevo socio.

## Archivos incluidos

### Nuevos

- `app/Modules/Administration/Controllers/AdminDeviceController.php`
- `app/Modules/Administration/Services/DeviceUnassignmentService.php`
- `database/migrations/2026_11_23_000100_add_device_unassignment_support.php`
- `public/assets/rhino-device-unassignment.js`
- `tests/Standalone/DeviceUnassignmentContractTest.php`
- `PATCHES/routes-api_v1.patch`
- `PATCHES/crm-blade.patch`
- `install.sh`

### Reemplazados

- `app/Modules/IoT/Services/DeviceManagementService.php`
- `app/Modules/IoT/Http/Middleware/VerifyEsp32Signature.php`
- `app/Modules/IoT/Domain/Entities/Device.php`

### Modificados mediante parche

- `routes/api_v1.php`
- `resources/views/crm.blade.php`

## Base de datos

La migración es incremental y agrega:

- `partner_id` nullable en `devices`.
- `location_id` nullable en `devices`.
- Movimiento `804`: báscula desvinculada del socio.
- Movimiento `805`: báscula reasignada a socio.

El `down()` es intencionalmente no destructivo. No se debe intentar volver `partner_id` o `location_id` a `NOT NULL` mientras existan dispositivos `UNASSIGNED`.

## Instalación por SSH

### 1. Respaldo

Antes de instalar:

- genera un respaldo de la base de datos MySQL/MariaDB;
- copia el código actual del CRM;
- confirma que el despliegue corresponde a la versión actual de RHINO 2.7.0 o posterior, con `personal_devices` y `campaign_device_availability`.

### 2. Copiar el paquete fuera del CRM

Sube el ZIP a tu directorio personal (`$HOME`), no a `~/rhinocrm`. Extrae el paquete en una carpeta temporal separada:

```bash
mkdir -p ~/rhino-device-update
unzip -o ~/RhinoCRM_Device_Unassignment_SuperAdmin_Update_2026-11-23_v2.zip -d ~/rhino-device-update
```

No descomprimas el ZIP directamente sobre el CRM: el instalador debe activar mantenimiento antes de copiar los archivos nuevos.

### 3. Ejecutar instalación segura

```bash
bash ~/rhino-device-update/install.sh ~/rhinocrm
```

El instalador:

- comprueba SHA-256 del paquete y que RHINO 2.7.0 esté aplicado;
- verifica los parches antes de poner el CRM en mantenimiento;
- activa mantenimiento antes de copiar cualquier archivo;
- instala los archivos nuevos y aplica los parches de API y Blade;
- ejecuta la migración incremental y limpia cachés;
- verifica la ruta administrativa, sintaxis PHP/JavaScript y el contrato de la actualización;
- quita mantenimiento automáticamente cuando todo termina correctamente.

Si el sitio ya estaba en mantenimiento antes de empezar, el instalador conserva ese estado. Si ocurre un error después de iniciar el despliegue, deja RHINO en mantenimiento para evitar ejecutar una actualización parcial. En ese caso, conserva el mensaje de error y no ejecutes `php artisan up` ni vuelvas a desplegar a ciegas; revisa el error y restaura el código de respaldo antes de reabrir el sitio.

### 4. Verificación manual

```bash
php artisan migrate:status | grep '2026_11_23_000100'
php artisan route:list --path=api/v1/admin/devices
php -l app/Modules/Administration/Services/DeviceUnassignmentService.php
php -l app/Modules/Administration/Controllers/AdminDeviceController.php
php -l app/Modules/IoT/Services/DeviceManagementService.php
```

Inicia sesión como `SUPER_ADMIN` y abre:

```text
Dispositivos → seleccionar socio → Básculas vinculadas
```

Debe aparecer el botón `Desvincular` junto a las acciones de suspensión/reactivación. Las cuentas de socios no deben ver ese botón y el backend debe rechazar cualquier intento que no venga de `SUPER_ADMIN`.

## Prueba funcional recomendada

Usa una báscula de prueba o un entorno de staging:

1. Registra una báscula con una MAC de prueba en el socio A.
2. Registra al menos una medición y confirma el `device_id`, `total_measurements` y `last_measurement_at`.
3. Si es posible, vincúlala a un evento activo y compártela como dispositivo personal.
4. Desde `SUPER_ADMIN`, desvincúlala indicando un motivo.
5. Confirma que ya no aparece en la lista del socio A y que su estado en `devices` es `UNASSIGNED`, con `partner_id` y `location_id` en `NULL`.
6. Confirma que las mediciones y los datos históricos continúan asociados al socio A.
7. Comprueba que una petición IoT con el secreto anterior se rechaza con `DEVICE_UNASSIGNED` mientras el dispositivo no esté reasignado.
8. Registra la misma MAC en el socio B mediante `POST /api/v1/devices`.
9. Confirma que el nuevo registro devuelve el mismo `device_id`, un secreto nuevo y `reused_unassigned_device: true`.
10. Comprueba que la báscula queda activa en el socio B y que el historial antiguo no se modificó.

## Seguridad y compatibilidad

- La ruta es `POST /api/v1/admin/devices/{id}/unassign`.
- El servicio valida `UserContextDTO::isSuperAdmin()` aunque la interfaz o la ruta se invoquen directamente.
- La operación se ejecuta en una transacción con bloqueo de la fila del dispositivo.
- La rotación del secreto bloquea la autenticación ESP32 anterior.
- El middleware responde `DEVICE_UNASSIGNED` para una báscula libre.
- No se agregan dependencias Composer.
- No se ejecutan migraciones destructivas ni se modifican filas históricas de mediciones.

## Restauración

No ejecutes un rollback destructivo: la migración no implementa reversión porque podría haber dispositivos sin socio y movimientos de reasignación posteriores. Si necesitas restaurar la versión anterior, utiliza el respaldo de código tomado antes de instalar. No restaures automáticamente la base de datos si la migración ya se aplicó: primero revisa si hubo mediciones, eventos o reasignaciones después de la actualización. Antes de restaurar, conserva el SQL de respaldo y solicita revisar el error y el estado de migraciones.
