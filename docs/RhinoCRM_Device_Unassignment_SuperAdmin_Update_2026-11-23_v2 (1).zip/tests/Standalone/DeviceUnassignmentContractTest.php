<?php

$root = dirname(__DIR__, 2);
$errors = [];

$read = static function (string $path) use ($root): string {
    $full = $root.'/'.$path;
    if (!is_file($full)) {
        throw new RuntimeException('Archivo requerido no encontrado: '.$path);
    }
    return (string) file_get_contents($full);
};

$routesPatch = $read('PATCHES/routes-api_v1.patch');
$bladePatch = $read('PATCHES/crm-blade.patch');
$migration = $read('database/migrations/2026_11_23_000100_add_device_unassignment_support.php');
$controller = $read('app/Modules/Administration/Controllers/AdminDeviceController.php');
$service = $read('app/Modules/Administration/Services/DeviceUnassignmentService.php');
$registration = $read('app/Modules/IoT/Services/DeviceManagementService.php');
$middleware = $read('app/Modules/IoT/Http/Middleware/VerifyEsp32Signature.php');
$entity = $read('app/Modules/IoT/Domain/Entities/Device.php');
$ui = $read('public/assets/rhino-device-unassignment.js');

foreach ([
    'AdminDeviceController::class' => 'La ruta de desvinculación debe usar el controlador administrativo.',
    "'/devices/{id}/unassign'" => 'La ruta POST de desvinculación no está definida en el parche.',
] as $needle => $message) {
    if (!str_contains($routesPatch, $needle)) $errors[] = $message;
}

foreach ([
    'rhino-device-unassignment.js' => 'La vista CRM debe cargar el nuevo script.',
] as $needle => $message) {
    if (!str_contains($bladePatch, $needle)) $errors[] = $message;
}

foreach ([
    "->nullable()->change()" => 'partner_id y location_id deben admitir NULL para básculas sin socio.',
    "'804'" => 'Debe existir el movimiento de desvinculación.',
    "'805'" => 'Debe existir el movimiento de reasignación.',
] as $needle => $message) {
    if (!str_contains($migration, $needle)) $errors[] = $message;
}

foreach ([
    'Solo SUPER_ADMIN' => 'La operación debe estar protegida en el servicio.',
    "'UNASSIGNED'" => 'La báscula debe quedar en estado UNASSIGNED.',
    "'partner_id' => null" => 'La asignación de socio debe quedar vacía.',
    "'location_id' => null" => 'La ubicación debe quedar vacía.',
    "'804'" => 'Debe registrarse el movimiento de desvinculación.',
    "'UNASSIGN'" => 'Debe quedar un registro de auditoría de seguridad.',
    "'RELEASED'" => 'Las disponibilidades personales de eventos deben liberarse.',
    "'INACTIVE'" => 'Las asociaciones tradicionales de eventos deben inactivarse.',
] as $needle => $message) {
    if (!str_contains($service, $needle)) $errors[] = $message;
}

foreach ([
    "'UNASSIGNED'" => 'El registro normal debe reconocer básculas libres.',
    "'805'" => 'La reasignación debe generar su propio movimiento.',
    "'reused_unassigned_device'" => 'La respuesta debe identificar una báscula reutilizada.',
    "->total_measurements" => 'La reasignación debe conservar el contador histórico.',
] as $needle => $message) {
    if (!str_contains($registration, $needle)) $errors[] = $message;
}

if (!str_contains($middleware, 'DEVICE_UNASSIGNED')) $errors[] = 'El middleware IoT debe rechazar explícitamente básculas sin socio.';
if (!str_contains($entity, "\$this->partnerId !== ''")) $errors[] = 'La entidad Device no debe considerar activa una báscula sin socio.';
if (!str_contains($ui, '/unassign')) $errors[] = 'La interfaz no llama al endpoint de desvinculación.';
if (!str_contains($ui, 'Administrador global')) $errors[] = 'El botón debe mostrarse únicamente a SUPER_ADMIN.';
$installer = $read('install.sh');
if (!str_contains($installer, 'TARGET_ROOT') || !str_contains($installer, 'php artisan down --retry=60')) $errors[] = 'El instalador debe desplegar desde una carpeta externa y activar mantenimiento antes de copiar archivos.';
if (!str_contains($installer, 'ATENCIÓN: la instalación falló')) $errors[] = 'El instalador debe dejar el CRM en mantenimiento si falla un paso posterior al despliegue.';

if ($errors !== []) {
    fwrite(STDERR, implode("\n", $errors)."\n");
    exit(1);
}

echo "DeviceUnassignmentContractTest OK\n";
